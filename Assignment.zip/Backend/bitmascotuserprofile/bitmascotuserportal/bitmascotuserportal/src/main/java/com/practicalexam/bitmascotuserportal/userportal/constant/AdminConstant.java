package com.practicalexam.bitmascotuserportal.userportal.constant;

public class AdminConstant {
    public static final String ADMIN_EMAIL = "admin@localhost.local";
    public static final String ADMIN_PASSWORD = "admin";
}
