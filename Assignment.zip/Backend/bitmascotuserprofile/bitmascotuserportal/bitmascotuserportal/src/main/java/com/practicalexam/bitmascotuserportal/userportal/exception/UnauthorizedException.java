package com.practicalexam.bitmascotuserportal.userportal.exception;

public class UnauthorizedException extends Exception{
    public UnauthorizedException(String message){
        super(message);
    }
}
