package com.practicalexam.bitmascotuserportal.userportal.exception;

public class InvalidException extends Exception{
    public InvalidException(String message){
        super(message);
    }
}
