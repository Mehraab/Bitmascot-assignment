package com.practicalexam.bitmascotuserportal.userportal.exception;

public class EmailNotUniqueException extends Exception{

    public EmailNotUniqueException(String message){
        super(message);
    }
}
