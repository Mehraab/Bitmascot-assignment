package com.practicalexam.bitmascotuserportal;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class BitMascotuserportalApplicationTests {

	@Test
	void contextLoads() {
	}

}
